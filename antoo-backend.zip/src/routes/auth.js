const router = require("express").Router();
const register = require("../controllers/auth/register");
const activation = require("../controllers/auth/activation");
const login = require("../controllers/auth/login");
const forgotPassword = require("../controllers/auth/forgot");

router.post("/register", register);
router.patch("/activation", activation);
router.post("/login", login);
router.patch("/forgot-password", forgotPassword);

module.exports = router;
